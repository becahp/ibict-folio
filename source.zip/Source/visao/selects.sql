--------------------------------------------------------------------------------
Trocar Fone por Telefone

SELECT * FROM `layer` WHERE description like '%DF%'

description: </br><b>Local: </b>  Brasília/DF</br><b>Fone: </b>(61) 3312-9910</br><base href="https://www.mdh.gov.br/juventude-1/" target="_blank"> <a href=institucional>Saiba Mais...</a>

UPDATE table_name
SET column1 = value1, column2 = value2, ...
WHERE condition;

UPDATE tablename
SET field_name = REPLACE(field_name , 'oldstring', 'newstring')
WHERE field_name LIKE ('oldstring%');

UPDATE `layer`
SET description = REPLACE(description, '<b>Fone: </b>','<b>Telefone: </b>')
WHERE description LIKE '%<b>Fone%';


--------------------------------------------------------------------------------
Adicionar Natureza Jurídica
UPDATE `layer`
SET description = REPLACE(description, '<base','<b>Natureza Jurídica: </b>Secretaria</br></br><base')
WHERE description LIKE '%<base%';

SELECT * FROM `layer` WHERE description like '%<base%'

--------------------------------------------------------------------------------
Consertar Natureza Jurídica
UPDATE `layer`
SET description = REPLACE(description, 'Secretaria','Diretoria')
WHERE description LIKE '%/AC%';

SELECT * FROM `layer` WHERE description like '%<base%'
SELECT * FROM `layer` WHERE group_id=4; 26
SELECT * FROM `layer` WHERE group_id=4 AND description LIKE '%Natureza%';

--------------------------------------------------------------------------------
Adicionar layer
INSERT INTO `layer` (`id`, `jhi_value`, `region_id`, `name_id`, `year_id`) VALUES ();


--------------------------------------------------------------------------------
Consertar taxa homicidio mulheres
SELECT * FROM `indicator` WHERE name_id=5 and year_id=2
SELECT * FROM `indicator` WHERE name_id=5 and year_id=3 and region_id=5728;

UPDATE `indicator`
SET `jhi_value` =
WHERE `name_id`=5 and `year_id`=3 and `region_id`=5728;


UPDATE `indicator` SET `jhi_value`='55555' WHERE `name_id`=5 and `year_id`=3 and `region_id`=5728);
UPDATE `indicator` SET `jhi_value`=55555 WHERE `name_id`=5 and `year_id`=3 and `region_id`=5728;
