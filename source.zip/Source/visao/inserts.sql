
INSERT INTO `indicator` (`id`, `jhi_value`, `region_id`, `name_id`, `year_id`) VALUES
(NULL, '1', '5716','19', '1'),
(NULL, '1', '5716','20', '1');




% Full texts 	id 	name 	geo_json 	jhi_type 	description 	jhi_date 	source 	date_change 	note 	icon_id 	group_id
INSERT INTO `layer` (`id`, `name`, `geo_json`, `jhi_type`, `description`, `jhi_date`, `source`, `date_change`, `note`, `icon_id`, `group_id`) VALUES
(NULL, '1', '5716','19', '1'),
(NULL, '1', '5716','20', '1');


29 	Conselho Municipal da Juventude 	[-22.742995, -47.322621] 	MARKER 	</br><b>Local: </b>  Americana/SP</br><b>Telefone:... 	2019-06-10 04:43:00 	NULL	2019-06-10 04:43:00 	NULL	NULL	5






INSERT INTO `layer` (`id`, `name`, `geo_json`, `jhi_type`, `description`, `jhi_date`, `source`, `date_change`, `note`, `icon_id`, `group_id`) VALUES(NULL,'Secretaria de Transparência e Participação Popular - Coordenadoria Municipal de Políticas para Juventude','[-28.645120, -53.602490]','MARKER','</br><b>Local: </b>Cruz Alta/RS</br><b>Telefone: </b>(55) 3321-1300</br><b>Natureza Jurídica: </b>Secretaria</br><base href="https://www.mdh.gov.br/juventude-1/" target="_blank"> <a href=institucional>Saiba Mais...</a>',NULL,NULL,NULL,NULL,NULL,'5');
