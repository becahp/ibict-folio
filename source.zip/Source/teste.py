#transforma dict em string
data1 = json.dumps(data['properties'],ensure_ascii=False, indent=4, sort_keys=True)

#transforma string em dict
data2 = json.loads(data1)
