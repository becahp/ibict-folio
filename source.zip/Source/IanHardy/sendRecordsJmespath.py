import jmespath
import requests
import settings

# folio settings
OKAPI = "https://folio-snapshot-core-okapi.aws.indexdata.com"
USER = "diku_admin"
PASS = "admin"
TENANT = "diku"

# solr settings
SOLR_INDEX = 'http://localhost:8080/solr/biblio'

# map, this goes somewhere else
instance_id = jmespath.compile('id')
instance_title = jmespath.compile('title')
instance_short_title = jmespath.compile('indexTitle')
instance_contributor = jmespath.compile('contributors[0].name')
instance_subjects = jmespath.compile('subjects')

def main():
    token = get_token(OKAPI, USER, PASS, TENANT)
    for instance in gen_instance_storage_records(token):
        vufind_doc = map_record(instance)
        print(vufind_doc['id'])
        print(index_record(vufind_doc))

def map_record(instance_record):
    vufind_document = {}

    vufind_document['id'] = instance_id.search(instance_record)
    vufind_document['title'] = instance_title.search(instance_record)
    vufind_document['title_short'] = instance_title.search(instance_record)
    vufind_document['title_full'] = instance_title.search(instance_record)
    vufind_document['author'] = instance_contributor.search(instance_record)
    vufind_document['topic'] = instance_subjects.search(instance_record)
    #vufind_document['fullrecord'] = settings.DUMMY_RECORD

    return vufind_document

def index_record(document):
    params = {
        'commit'  : 'true',
        'json.command' : 'false'
    }
    r = requests.post(SOLR_INDEX + '/update',
                      params=params,
                      json=document)
    
    return r.status_code

def gen_instance_storage_records(token):
    count = 0
    limit = 5
    headers = {
        "X-Okapi-Tenant" : TENANT,
        "X-Okapi-Token" : token,
        "Accept" : "application/json"
    }
    params = {
        "offset" : 0,
        "limit" : 50
    }
    r = requests.get(OKAPI + '/instance-storage/instances',
                     headers=headers)
    total_records = r.json()['totalRecords']
    while count < total_records:
        instances_json = r.json()
        page_count = 0
        page_size = len(instances_json['instances'])
        page_count += 1
        count += 1
        params['offset'] += limit

        if page_count == page_size:
            r = requests.get(OKAPI + '/instance-storage/instance',
                             headers=headers,
                             params=params)
        
        yield instances_json['instances'][page_count]


def get_token(okapi, username, password, tenant):
    headers = {"X-Okapi-Tenant": tenant}
    payload = {
        "username" : username,
        "password" : password
    }
    r = requests.post(okapi + '/authn/login', 
                      headers=headers, json=payload)
    return r.headers['x-okapi-token']

if __name__ == "__main__":
    main()
