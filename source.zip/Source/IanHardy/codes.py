import argparse
import jmespath
import requests
import json

file_name = 'exampleContributors.json'
f = open(file_name,encoding='utf-8')
jsonStr = f.read()
instance_record = json.loads(jsonStr)
vufind_document = {}

#instance_record = data
# map
instance_id = jmespath.compile('id')
instance_title = jmespath.compile('title')
instance_short_title = jmespath.compile('indexTitle')
instance_contributor = jmespath.compile('contributors[*].name')
instance_subjects = jmespath.compile('subjects')
instance_edition = jmespath.compile('editions')
instance_series = jmespath.compile('series')
instance_language = jmespath.compile('languages')
instance_title_alt = jmespath.compile('alternativeTitles[*].alternativeTitle')
instance_publisher = jmespath.compile('publication[*].publisher')
instance_publishDate = jmespath.compile('publication[*].dateOfPublication')

vufind_document = {}

vufind_document['id'] = instance_id.search(instance_record)
vufind_document['title'] = instance_title.search(instance_record)
vufind_document['title_short'] = instance_short_title.search(instance_record)
vufind_document['title_full'] = instance_title.search(instance_record)
vufind_document['author'] = instance_contributor.search(instance_record)
vufind_document['topic'] = instance_subjects.search(instance_record)
#minhas
vufind_document['edition'] = instance_edition.search(instance_record)
vufind_document['series'] = instance_series.search(instance_record)
vufind_document['language'] = instance_language.search(instance_record)
vufind_document['title_alt'] = instance_title_alt.search(instance_record)
vufind_document['publisher'] = instance_publisher.search(instance_record) #['publication'][0]['publisher']
vufind_document['publishDate'] = instance_publishDate.search(instance_record) #['publication'][0]['dateOfPublication']

vufind_document

#---------------------------------------------------------------------------
#get all names, works to bring only names not contributorNameTypeId
instance_contributor = jmespath.compile('contributors[*].name')
#get all names and return only the first
instance_contributor = jmespath.compile('contributors[*].name | [0]')

#save first name in author
vufind_document = {}
vufind_document['author'] = instance_contributor.search(instance_record)

#---------------------------------------------------------------------------
instance_title_alt = jmespath.compile('alternativeTitles[*].alternativeTitle')
vufind_document['title_alt'] = instance_title_alt.search(instance_record)

#---------------------------------------------------------------------------
instance_publisher = jmespath.compile('publication[*].publisher')
vufind_document['publisher'] = instance_publisher.search(instance_record)

instance_publishDate = jmespath.compile('publication[*].dateOfPublication')
vufind_document['publishDate'] = instance_publishDate.search(instance_record)
#---------------------------------------------------------------------------
instance_physical = jmespath.compile('physicalDescriptions')
vufind_document['physical'] = instance_physical.search(instance_record)
#---------------------------------------------------------------------------
instance_url = jmespath.compile('electronicAccess[*].uri')
vufind_document['url'] = instance_url.search(instance_record)
#---------------------------------------------------------------------------

instance_isbn = jmespath.compile('identifiers[?identifierTypeId == `8261054f-be78-422d-bd51-4ed9f33c3422`].value')
instance_issn = jmespath.compile('identifiers[?identifierTypeId == `913300b2-03ed-469a-8179-c1092c991227`].value')
instance_lccn = jmespath.compile('identifiers[?identifierTypeId == `c858e4f2-2b6b-4385-842b-60732ee14abb`].value')
instance_oclc = jmespath.compile('identifiers[?identifierTypeId == `439bfbae-75bc-4f74-9fc7-b2a2d47ce3ef`].value')

vufind_document['isbn'] = instance_isbn.search(instance_record)
vufind_document['issn'] = instance_issn.search(instance_record)
vufind_document['lccn'] = instance_lccn.search(instance_record)
vufind_document['oclc_num'] = instance_oclc.search(instance_record)

#"8261054f-be78-422d-bd51-4ed9f33c3422": ISBN
#"913300b2-03ed-469a-8179-c1092c991227": ISSN
#"c858e4f2-2b6b-4385-842b-60732ee14abb": LCCN
#"439bfbae-75bc-4f74-9fc7-b2a2d47ce3ef": OCLC


identifiers[?identifierTypeId == 'uuid_of_id_type'].value

{'isbn': [{'value': '9788572324113', 'identifierTypeId': '5d164f4b-0b15-4e42-ae75-cfcf85318ad9'}, {'value': '9788572324113', 'identifierTypeId': '8261054f-be78-422d-bd51-4ed9f33c3422'}]}
{'isbn': [{'value': '1011162431', 'identifierTypeId': '5d164f4b-0b15-4e42-ae75-cfcf85318ad9'}, {'value': '(DE-599)GBV1011162431', 'identifierTypeId': '7e591197-f335-4afb-bc6d-a6d76ca3bace'}]}

{'isbn': [{'value': '97885987570559788598757056', 'identifierTypeId': '5d164f4b-0b15-4e42-ae75-cfcf85318ad95d164f4b-0b15-4e42-ae75-cfcf85318ad9'}, {'value': '9788598757055', 'identifierTypeId': '8261054f-be78-422d-bd51-4ed9f33c3422'}, {'value': '9788598757056', 'identifierTypeId': '8261054f-be78-422d-bd51-4ed9f33c3422'}]}


folio_isbn = "8261054f-be78-422d-bd51-4ed9f33c3422"

instance_isbn = jmespath.compile('identifiers')
vufind_document = {}
vufind_document['isbn'] = instance_isbn.search(instance_record)
vufind_document


#---------------------------------------------------------------------------
instance_formats = jmespath.compile('instanceFormatIds') #list of ids
algo = instance_formats.search(instance_record)
vufind_document['format'] = algo
