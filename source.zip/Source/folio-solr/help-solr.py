#import requests
import json

#----------------------------------------------------------------
#Pegar jsonGrande

#res = requests.get('https://api.github.com/users/becahp')
#data = res.json()
#print(data['login'])

# Search GitHub's repositories for requests
#response = requests.get(
#    'https://api.github.com/search/repositories',
#    params={'q': 'requests+language:python'},
#)
#----------------------------------------------------------------

f = open('all.json',encoding='utf-8')
jsonStr = f.read() #transforma o file em string

pos = jsonStr.find('{') #encontrar primeiro { no arquivo, que é o início do json
jsonGrande = jsonStr[pos:] #criar o json grande na memória

data = json.loads(jsonGrande) #transformou jsonGrande em um dict
#print(data)

#cada linha é um string
#json_string = json.dumps(data['instances'][0], ensure_ascii=False, indent=4)
#transforma cada linha em um dict
#folioReg = json.loads(json_string)


#data['instances'] é uma lista, mas #data['instances'][x] e um dict
#data['instances'][i].items()
folioReg = data['instances'][0]
solrReg = {
    'id': folioReg['hrid'],
    'title': folioReg['title'],
    'title_alt': folioReg['alternativeTitles'],
    'edition': folioReg['editions'],
    'series': folioReg['series'],
    'author': folioReg['contributors'][0]['name'],
    'topic': folioReg['subjects'],
    'publisher': folioReg['publication'][0]['publisher'],
    'publishDate': folioReg['publication'][0]['dateOfPublication'],
    'language': folioReg['languages'],
    'recordtype': folioReg['sourceRecordFormat']
    }

solrJson = json.dumps(solrReg, ensure_ascii=False, indent=4)

#são lista e não valores
#edition
#series

#print(a['instances'][0])
#print(a['instances'][0]['title'])

#for element in data['instances']:
#    print(element['title'])

#python_obj = json.loads(jsonGrande)
#print(json.dumps(python_obj, sort_keys=True, indent=4))

#json_string = json.dumps(data)
#print(json.dumps(json_string, sort_keys=True, indent=4))

#a = json.dumps(data['instances'])
#print(a[0])
#print(a[0]['title'])


# here we create new data_file.json file with write mode using file i/o operation
# write json data into file
with open('json_file.json', "w") as file_write:
    json.dump(solrReg, file_write, ensure_ascii=False, indent=4)
#solrJson = json.dumps(solrReg, ensure_ascii=False, indent=4)


curl -w '\n' -D - -X GET -H "Content-type: application/json" -H "Accept: application/json" -H "X-Okapi-Tenant: diku" -H "X-Okapi-Token: eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJkaWt1X2FkbWluIiwidXNlcl9pZCI6ImZlNWM5YzM3LTAxNDItNDc4OC04YTk2LWIxMjE4MWZiMjdkNCIsImNhY2hlX2tleSI6IjA2N2M4NmM4LTg5ZGQtNDE4Zi04MWIwLTg4MTA3YmRhZGM4NyIsImlhdCI6MTU1ODAxNTI0OSwidGVuYW50IjoiZGlrdSJ9.RmDxSRTLsQD_4S9d6-KOwSmPpVwJdUUAQyhlZ7RgkOw" http://localhost:9130/source-storage/records
