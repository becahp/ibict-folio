folioReg = dados['instances'][i]
folioReg['hrid'],
folioReg['title'],
folioReg['alternativeTitles'],
folioReg['editions'],
folioReg['series'],
folioReg['contributors'][0]['name'],
folioReg['subjects'],
folioReg['publication'][0]['publisher'],
folioReg['publication'][0]['dateOfPublication'],
folioReg['languages']

folioReg['contributors'][0]['name']
folioReg['publication'][0]['publisher']
folioReg['publication'][0]['dateOfPublication']

solrReg = {
    'id': folioReg['hrid'],
    'title': folioReg['title'],
    'title_alt': folioReg['alternativeTitles'],
    'edition': folioReg['editions'],
    'series': folioReg['series'],
    'author': folioReg['contributors'][0]['name'],
    'topic': folioReg['subjects'],
    'publisher': folioReg['publication'][0]['publisher'],
    'publishDate': folioReg['publication'][0]['dateOfPublication'],
    'language': folioReg['languages']
    }


folioReg = dados['instances'][i] #muda com o i
##checar campos problemáticos
#contributors
if len(folioReg['contributors']): #diferente de zero
   auxContributors = folioReg['contributors'][0]['name']
else:
   auxContributors = []
#alternativeTitles
if len(folioReg['alternativeTitles']): #diferente de zero
    auxAltTitles = folioReg['alternativeTitles'][0]['alternativeTitle']
else:
    auxAltTitles = []
##publication
if len(folioReg['publication']): #diferente de zero
    #publisher
    if 'publisher' in folioReg['publication'][0]:
        auxPublisher = folioReg['publication'][0]['publisher']
    else:
        auxPublisher = []
    #dateOfPublication
    if 'dateOfPublication' in folioReg['publication'][0]:
        auxDateOfPublication = folioReg['publication'][0]['dateOfPublication']
    else:
        auxDateOfPublication = []
else:
   auxPublisher = []
   auxDateOfPublication = []
#Dicionario
solrReg = {
'id': folioReg['hrid'],
'title': folioReg['title'],
'title_alt': auxAltTitles,
'edition': folioReg['editions'],
'series': folioReg['series'],
'author': auxContributors,
'topic': folioReg['subjects'],
'publisher': auxContributors,
'publishDate': auxDateOfPublication,
'language': folioReg['languages']
}
solrJson = json.dumps(solrReg, ensure_ascii=False, indent=4, sort_keys=True)
data=solrJson.encode()
print("Enviando o item " + str(i))
r = requests.post(url, headers=headers, params=params, data=data)
print("Resposta " + str(r.status_code))
