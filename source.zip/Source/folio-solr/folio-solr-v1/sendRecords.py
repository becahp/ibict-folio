import requests
import json

#example
#url = 'https://api.github.com/some/endpoint'
#payload = {'some': 'data'}
#headers = {'content-type': 'application/json'}
#r = requests.post(url, data=json.dumps(payload), headers=headers)

#----------------------------------------------------------------
#Get Okapi-token
url = 'http://localhost:9130/authn/login'
payload = {"username":"diku_admin","password":"admin"}
headers = {'Content-type': 'application/json', "Accept": "application/json", "X-Okapi-Tenant": "diku"}
r = requests.post(url, headers=headers, data=json.dumps(payload))
token = r.headers['x-okapi-token']
#print(token)

#----------------------------------------------------------------
#Request one instance to get totalRecords
url = 'http://localhost:9130/instance-storage/instances'
params = {'limit':'1'}
payload = {"username":"diku_admin","password":"admin"}
headers = {'Content-type': 'application/json', "Accept": "application/json", "X-Okapi-Tenant": "diku", "X-Okapi-Token": token}
r = requests.get(url, headers=headers, params=params, data=json.dumps(payload))
response = r.json()
total = response['totalRecords']

#----------------------------------------------------------------
#Get all instances
url = 'http://localhost:9130/instance-storage/instances'
params = {'limit':total}
payload = {"username":"diku_admin","password":"admin"}
headers = {'Content-type': 'application/json', "Accept": "application/json", "X-Okapi-Tenant": "diku", "X-Okapi-Token": token}
r = requests.get(url, headers=headers, params=params, data=json.dumps(payload))
dados = r.json() #this is one dictonary with totalRecords and instances


#----------------------------------------------------------------
#Convert to solr
url = 'http://localhost:8080/solr/biblio/update'
params ={'commit': 'true', 'json.command': 'false'}
headers = {'Content-type': 'application/json'}

listaErros = [] #to check later
for i in range(len(dados['instances'])):
    folioReg = dados['instances'][i]
    ##Check problematic fields
    #contributors
    if len(folioReg['contributors']): #not zero
        auxContributors = folioReg['contributors'][0]['name']
    else:
        auxContributors = []
    #alternativeTitles
    if len(folioReg['alternativeTitles']): #not de zero
        auxAltTitles = folioReg['alternativeTitles'][0]['alternativeTitle']
    else:
        auxAltTitles = []
    ##publication
    if len(folioReg['publication']): #not de zero
        #publisher
        if 'publisher' in folioReg['publication'][0]:
            auxPublisher = folioReg['publication'][0]['publisher']
        else:
            auxPublisher = []
        #dateOfPublication
        if 'dateOfPublication' in folioReg['publication'][0]:
            auxDateOfPublication = folioReg['publication'][0]['dateOfPublication']
        else:
            auxDateOfPublication = []
    else:
        auxPublisher = []
        auxDateOfPublication = []
    #Dictionary
    solrReg = {
    'id': folioReg['hrid'],
    'title': folioReg['title'],
    'title_alt': auxAltTitles,
    'edition': folioReg['editions'],
    'series': folioReg['series'],
    'author': auxContributors,
    'topic': folioReg['subjects'],
    'publisher': auxPublisher,
    'publishDate': auxDateOfPublication,
    'language': folioReg['languages']
    }
    solrJson = json.dumps(solrReg, ensure_ascii=False, indent=4, sort_keys=True)
    data=solrJson.encode()
    print("Sending item " + str(i))
    r = requests.post(url, headers=headers, params=params, data=data)
    #print("Answer " + str(r.status_code))
    if r.status_code != 200:
        listaErros.append(i)

print(listaErros)
