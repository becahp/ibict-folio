import requests
import json

#example
#url = 'https://api.github.com/some/endpoint'
#payload = {'some': 'data'}
#headers = {'content-type': 'application/json'}
#r = requests.post(url, data=json.dumps(payload), headers=headers)

#----------------------------------------------------------------
#Pegar Okapi-token
url = 'http://localhost:9130/authn/login'
payload = {"username":"diku_admin","password":"admin"}
headers = {'Content-type': 'application/json', "Accept": "application/json", "X-Okapi-Tenant": "diku"} #-H "Content-type: application/json" -H "Accept: application/json" -H "X-Okapi-Tenant: diku"
r = requests.post(url, headers=headers, data=json.dumps(payload))
token = r.headers['x-okapi-token']
print(token)

#----------------------------------------------------------------
#Pegar uma instancia para saber quantas tem ao todo
url = 'http://localhost:9130/instance-storage/instances'
params = {'limit':'1'}
payload = {"username":"diku_admin","password":"admin"}
headers = {'Content-type': 'application/json', "Accept": "application/json", "X-Okapi-Tenant": "diku", "X-Okapi-Token": token}
r = requests.get(url, headers=headers, params=params, data=json.dumps(payload))
response = r.json()
total = response['totalRecords']

#----------------------------------------------------------------
#Pegar todas as instancias
url = 'http://localhost:9130/instance-storage/instances'
params = {'limit':total}
payload = {"username":"diku_admin","password":"admin"}
headers = {'Content-type': 'application/json', "Accept": "application/json", "X-Okapi-Tenant": "diku", "X-Okapi-Token": token}
r = requests.get(url, headers=headers, params=params, data=json.dumps(payload)) #estou com jsonGrande
dados = r.json() #tenho um dicionario com totalRecords e instances

##verificar tamanho de dados
#len(dados['instances'])


#----------------------------------------------------------------
#Converter para solr

url = 'http://localhost:8080/solr/biblio/update'
params ={'commit': 'true', 'json.command': 'false'}
headers = {'Content-type': 'application/json'}

listaErros = []
for i in range(len(dados['instances'])):
for i in listaErros:
    folioReg = dados['instances'][i] #muda com o i
    ##checar campos problemáticos
    #contributors
    if len(folioReg['contributors']): #diferente de zero
       auxContributors = folioReg['contributors'][0]['name']
    else:
       auxContributors = []
    #alternativeTitles
    if len(folioReg['alternativeTitles']): #diferente de zero
       auxAltTitles = folioReg['alternativeTitles'][0]['alternativeTitle']
    else:
       auxAltTitles = []
    ##publication
    if len(folioReg['publication']): #diferente de zero
        #publisher
        if 'publisher' in folioReg['publication'][0]:
            auxPublisher = folioReg['publication'][0]['publisher']
        else:
            auxPublisher = []
        #dateOfPublication
        if 'dateOfPublication' in folioReg['publication'][0]:
            auxDateOfPublication = folioReg['publication'][0]['dateOfPublication']
        else:
            auxDateOfPublication = []
    else:
       auxPublisher = []
       auxDateOfPublication = []
    #Dicionario
    solrReg = {
        'id': folioReg['hrid'],
        'title': folioReg['title'],
        'title_alt': auxAltTitles,
        'edition': folioReg['editions'],
        'series': folioReg['series'],
        'author': auxContributors, #folioReg['contributors'][0]['name'],
        'topic': folioReg['subjects'],
        'publisher': auxPublisher,
        'publishDate': auxDateOfPublication,
        'language': folioReg['languages']
        }
    solrJson = json.dumps(solrReg, ensure_ascii=False, indent=4, sort_keys=True)
    data=solrJson.encode()
    print("Enviando o item " + str(i))
    r = requests.post(url, headers=headers, params=params, data=data)
    #print("Resposta " + str(r.status_code)) #str(solr['responseHeader']['status']) #solr=r.json()
    if r.status_code != 200:
        print(i)
        #listaErros.append(i)

#listaErros
#[22, 28, 33, 53, 55, 61, 239, 343, 347, 366, 401, 409, 564, 605, 647]



>>> r = requests.post(url, headers=headers, params=params, data=data)
>>> r.text
'{\n  "responseHeader":{\n    "status":0,\n    "QTime":24}}\n'
>>> exit()

if len(folioReg['contributors'])
    folioReg['contributors'][0]['name'] = ''
folioReg['contributors'][0]['name']
folioReg['publication'][0]['publisher']
folioReg['publication'][0]['dateOfPublication']

if len(folioReg['publication']): #diferente de zero

else:
   auxPublisher = []
   auxDateOfPublication = []


    if 'publisher' in folioReg['publication'][0]:
        auxPublisher = folioReg['publication'][0]['publisher']
    else:
        auxPublisher = []
if 'dateOfPublication' in folioReg['publication'][0]:
    auxDateOfPublication = folioReg['publication'][0]['dateOfPublication']
else:
    auxDateOfPublication = []

folioReg = data['instances'][0] #apenas para 1
solrReg = {
    'id': folioReg['hrid'],
    'title': folioReg['title'],
    'title_alt': folioReg['alternativeTitles'],
    'edition': folioReg['editions'],
    'series': folioReg['series'],
    'author': folioReg['contributors'][0]['name'],
    'topic': folioReg['subjects'],
    'publisher': folioReg['publication'][0]['publisher'],
    'publishDate': folioReg['publication'][0]['dateOfPublication'],
    'language': folioReg['languages']
    }

solrJson = json.dumps(solrReg, ensure_ascii=False, indent=4, sort_keys=True)

#----------------------------------------------------------------
#Enviar para solr

#Pegar uma instancia para saber quantas tem ao todo
url = 'http://localhost:8080/solr/biblio/update'
params ={'commit': 'true', 'json.command': 'false'}
headers = {'Content-type': 'application/json'}
data=solrJson
r = requests.post(url, headers=headers, params=params, data=data)
r.text
response = r.json()

data = '[{
    "id": "in00002182",
    "title": "O Contrapoder popular /",
    "title_alt": [],
    "edition": [],
    "series": [],
    "author": "Pereira, Cristóvão",
    "topic": [
        "Ética",
        "Ciência política",
        "Cristianismo"
    ],
    "publisher": "Perffil Editora, ",
    "publishDate": "2005.",
    "language": [
        "por "
    ],
    "recordtype": "MARC-JSON"
}]'

data=open('example.file', 'rb')
curl -X POST -H 'Content-Type: application/json' 'http://localhost:8080/solr/biblio/update?commit=true' --data-binary '[{
    "id": "in00002182",
    "title": "O Contrapoder popular /",
    "title_alt": [],
    "edition": [],
    "series": [],
    "author": "Pereira, Cristóvão",
    "topic": [
        "Ética",
        "Ciência política",
        "Cristianismo"
    ],
    "publisher": "Perffil Editora, ",
    "publishDate": "2005.",
    "language": [
        "por "
    ],
    "recordtype": "MARC-JSON"
}]'

solrJson = json.dumps(solrReg, ensure_ascii=False, indent=4)
data=solrJson.encode('utf8')

#------------------------------------------------------------------------------ Bibliotecas
import requests, json
tenant = "diku"
username = "diku_admin"
password = "admin"
#------------------------------------------------------------------------------ Login
okapi = 'https://folio-snapshot-core-okapi.aws.indexdata.com'
okapi = 'http://localhost:9130'
payload = {"username":"diku_admin","password":"admin"}
headers = {"X-Okapi-Tenant": tenant}
#r = requests.post(okapi + '/authn/login', headers=headers, data=json.dumps(payload))
r = requests.post(okapi + '/authn/login', headers=headers, json=payload)
token = r.headers['x-okapi-token']
print(token)

#------------------------------------------------------------------------------ identifierTypes
headers = {
    "X-Okapi-Tenant" : tenant,
    "X-Okapi-Token" : token,
    "Accept" : "application/json"
}
params = {
    "offset" : 0,
    "limit": 17,
    "query": 'name=="i*"'
}
identifierTypeId = '8261054f-be78-422d-bd51-4ed9f33c3422'
identifierType

r = requests.get(okapi + '/identifier-types',headers=headers,params=params) #
r = requests.get(okapi + '/identifier-types/' + identifierTypeId,headers=headers,params=params)
r = requests.get(okapi + '/identifier-types/identifierType/ISBN',headers=headers,params=params) #

#r = requests.get(okapi + '/instance-storage/instances',headers=headers,params=params)
#r = requests.get('http://localhost:9130/instance-storage/instances',headers=headers,params=params)

params = {"identifierTypeId" : '8261054f-be78-422d-bd51-4ed9f33c3422'}
headers = {'Content-type': 'application/json', "Accept": "application/json", "X-Okapi-Tenant": "diku", "X-Okapi-Token": token}
r = requests.get(okapi + 'identifier-types',headers=headers,params=params)

response = r.json()
print(response)

 /identifier-types/{identifierTypeId}

 #------------------------------------------------------------------------------ instanceId
headers = {
    "X-Okapi-Tenant" : tenant,
    "X-Okapi-Token" : token,
    "Accept" : "text/plain"
}
instanceId='a89eccf0-57a6-495e-898d-32b9b2210f2f'
instanceId='7dbec26a-46d4-4bb1-bfe0-8403fb9aada0'
r = requests.get(okapi + '/instance-storage/instances/'+ instanceId, headers=headers)
response = r.json()
print(response)

#------------------------------------------------------------------------------
identifierTypes = r.json()['identifierTypes'] #ids as list
>>> identifierTypes[0]
{'id': '8e3dd25e-db82-4b06-8311-90d41998c109', 'name': 'Standard Technical Report Number'}
>>> identifierTypes[0]['id']
'8e3dd25e-db82-4b06-8311-90d41998c109'
>>> identifierTypes[0]['name']
'Standard Technical Report Number'


for i in range(len(identifierTypes)):
    if identifierTypes[i]['name'] == 'ISBN':
        print(str(i) + 'ISBN')
    if identifierTypes[i]['name'] == 'OCLC':
        print(str(i)+ 'hey')


for i in range(len(identifier_type)):
    if identifier_type[i]['name'] == 'ISBN':
        isbn_code = identifier_type[i]['id']
        print(isbn_code)
    if identifier_type[i]['name'] == 'ISSN':
        issn_code = identifier_type[i]['id']
        print(issn_code)
    if identifier_type[i]['name'] == 'LCCN':
        lccn_code = identifier_type[i]['id']
        print(lccn_code)
    if identifier_type[i]['name'] == 'OCLC':
        oclc_code = identifier_type[i]['id']
        print(oclc_code)

print(isbn_code)
print(issn_code)
print(lccn_code)
print(oclc_code)

#------------------------------------------------------------------------------com query
headers = {
    "X-Okapi-Tenant" : tenant,
    "X-Okapi-Token" : token,
    "Accept" : "application/json"
}
params = {
    "offset" : 0,
    "query": 'name=="isbn" or name=="issn" or name=="lccn" or name=="oclc"'
}
r = requests.get(okapi + '/identifier-types',headers=headers,params=params) #
response = r.json()
print(response)
identifier_type = r.json()['identifierTypes'] #ids as list
#------------------------------------------------------------------------------com query expansiva
identifier = 'isbn'
headers = {
    "X-Okapi-Tenant" : tenant,
    "X-Okapi-Token" : token,
    "Accept" : "application/json"
}
params = {
    "offset" : 0,
    "query": 'name=="' + identifier + '"'
}
r = requests.get(okapi + '/identifier-types',headers=headers,params=params) #
response = r.json()
print(response)
#------------------------------------------------------------------------------format
headers = {
    "X-Okapi-Tenant" : tenant,
    "X-Okapi-Token" : token,
    "Accept" : "application/json"
}
params = {
"offset" : 0,
"limit" : 100
#"query": 'id=="' + identifier + '"'
}
r = requests.get(okapi + '/instance-formats',
             headers=headers,
             params=params)
list = r.json()['instanceFormats']

instance_formats = {}
for i in range(len(list)):
    name = list[i]['name']
    id = list[i]['id']
    instance_formats[id] = name

#dict[key] = value

>>> instance_formats[0]
{'source': 'rdacarrier', 'name': 'audio -- audio cylinder', 'id': '485e3e1d-9f46-42b6-8c65-6bb7bd4b37f8', 'code': 'se'}
>>> type(instance_formats[0])
<class 'dict'>
>>> instance_formats[0]['name']
'audio -- audio cylinder'
>>> instance_formats[0]['id']
'485e3e1d-9f46-42b6-8c65-6bb7bd4b37f8'
>>>
